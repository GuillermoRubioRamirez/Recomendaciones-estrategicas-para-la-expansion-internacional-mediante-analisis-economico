# Abrir ficheros  ----
datos_pib_ipc <- read.csv("Datos/Originales/pib_ipc_paises_punto2.csv")
datos_exogenas <- read.xlsx2("Datos/Originales/exogenas_paises_punto2.xlsx", 1)

# Limpieza ----
# Filtrar los datos por el pais que nos ha tocado (Italia)
datos_pib_ipc_italia <- datos_pib_ipc %>% filter(Country == "Italy")
datos_exogenas_italia <- datos_exogenas %>% filter(Country == "Italy")

# Borrar las columnas innecesarias
datos_pib_ipc_italia <- datos_pib_ipc_italia[,-c(1,2,3)]
datos_exogenas_italia <- datos_exogenas_italia[,-c(1,2,3)]

#Previsualización de los datos ----
dim(datos_pib_ipc_italia)
str(datos_pib_ipc_italia)
head(datos_pib_ipc_italia)
colnames(datos_pib_ipc_italia)

dim(datos_exogenas_italia)
str(datos_exogenas_italia)
head(datos_exogenas_italia)
colnames(datos_exogenas_italia)

# Summaries ----
print("SUMMARY")

summary(datos_pib_ipc_italia) %>% print()
summary(datos_exogenas_italia) %>% print()

#Separamos la tabla de pib e ipc en dos 
datos_ipc_italia<-datos_pib_ipc_italia[,c(1,2,4)]
datos_pib_italia<-datos_pib_ipc_italia[,c(1,2,3)]

#Eliminamos NA de la tabla del pib
datos_pib_italia<-na.omit(datos_pib_italia)
datos_ipc_italia<-na.omit(datos_ipc_italia)
datos_exogenas_italia<-na.omit(datos_exogenas_italia)

# Escribir ----

if (!dir.exists("Datos/Transformados")) {
  dir.create("Datos/Transformados")
}
write.csv(datos_pib_italia,file="Datos/Transformados/pib_italia.csv",row.names = FALSE)
write.csv(datos_ipc_italia,file="Datos/Transformados/ipc_italia.csv",row.names = FALSE)
write.csv(datos_exogenas_italia, file = "Datos/Transformados/exogenas_italia.csv", row.names = FALSE)

#Comprobamos si existen duplicidades
duplicados_ipc<-duplicated(datos_ipc_italia)
table(duplicados_ipc)
duplicados_pib<-duplicated(datos_pib_italia)
table(duplicados_pib)
duplicados_exogenas<-duplicated(datos_exogenas_italia)

table(duplicados_exogenas)
