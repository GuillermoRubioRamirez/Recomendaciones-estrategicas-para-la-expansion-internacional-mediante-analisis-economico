# Leer ficheros
datos_pib_italia <- read.csv("Datos/Transformados/pib_italia.csv")
datos_ipc_italia <- read.csv("Datos/Transformados/ipc_italia.csv")
datos_exogenas_italia <- read.csv("Datos/Transformados/exogenas_italia.csv")


# Crear carpeta para guardar plots ----
if (!dir.exists("Graficos")) {
  dir.create("Graficos")
}

if (!dir.exists("Graficos/EDA")) {
  dir.create("Graficos/EDA")
}


# Histogramas ----
p <- datos_pib_italia %>% 
  ggplot(aes(x=GDP.billion.currency.units)) +
  geom_histogram(fill = "dodgerblue", binwidth = 5) +
  labs(x="PIB") + 
  theme_minimal()

print(p)

ggsave(filename = 'Graficos/EDA/histograma_pib.png', plot = p)

####
p2 <- datos_ipc_italia %>% 
  ggplot(aes(x=Consumer.Price.Index..CPI.)) +
  geom_histogram(fill = "dodgerblue", binwidth = 5) +
  labs(x="IPC") + 
  theme_minimal()

print(p2)

ggsave(filename = 'Graficos/EDA/histograma_ipc.png', plot = p2)

####
p3 <- datos_exogenas_italia %>% 
  ggplot(aes(x=Money.supply.billion.currency.units)) +
  geom_histogram(fill = "dodgerblue", binwidth = 5) +
  labs(x="Money supply") + 
  theme_minimal()

print(p3)

ggsave(filename = 'Graficos/EDA/histograma_moneysupply.png', plot = p3)

####
p4 <- datos_exogenas_italia %>% 
  ggplot(aes(x=Unemployment.rate.percent)) +
  geom_histogram(fill = "dodgerblue", binwidth = 5) +
  labs(x="Unemplyment rate") + 
  theme_minimal()

print(p4)

ggsave(filename = 'Graficos/EDA/histograma_unemploymentrate.png', plot = p4)

####
p5 <- datos_exogenas_italia %>% 
  ggplot(aes(x=Stock.market.index)) +
  geom_histogram(fill = "dodgerblue", binwidth = 5) +
  labs(x="Stock market index") + 
  theme_minimal()

print(p5)

ggsave(filename = 'Graficos/EDA/histograma_sotckmarketindex.png', plot = p5)
