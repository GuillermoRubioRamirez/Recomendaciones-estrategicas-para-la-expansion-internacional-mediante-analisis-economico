if (!require(influxdbclient)){   
  install.packages("influxdbclient") 
}
library(influxdbclient)

if (!require(influxdbr)){   
  install.packages("influxdbr") 
}
library(influxdbr)

if (!require(httr)){   
  install.packages("httr") 
}
library(httr)

if (!require(forecast)){   
  install.packages("forecast") 
}
library(forecast)

if (!require(fpp2)){   
  install.packages("fpp2") 
}
library(fpp2)

if (!require(tseries)){   
  install.packages("tseries") 
}
library(tseries)

if (!require(dplyr)){   
  install.packages("dplyr") 
}
library(dplyr)

if (!require(xlsx)){   
  install.packages("xlsx") 
}
library(xlsx)

if (!require(ggplot2)){   
  install.packages("ggplot2") 
}
library(ggplot2)
