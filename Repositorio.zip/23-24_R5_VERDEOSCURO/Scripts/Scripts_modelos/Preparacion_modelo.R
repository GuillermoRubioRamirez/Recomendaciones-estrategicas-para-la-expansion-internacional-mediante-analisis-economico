# Leer ficheros  ----
datos_pib_italia <- read.csv("Datos/Transformados/pib_italia.csv")
datos_ipc_italia <- read.csv("Datos/Transformados/ipc_italia.csv")
datos_exogenas_italia <- read.csv("Datos/Transformados/exogenas_italia.csv")

#MODELIZACION DEL PIB ----------------------------------------------------------
# Convertir en serie temporal  ----
is.ts(datos_pib_italia)
datos_pib_ts <- ts(datos_pib_italia[,3], start = c(1996,1), end = c(2022,2), frequency = 4)

# Graficar los datos y grafico de autocorrelaciones  ----
ts.plot(datos_pib_ts) #Se pueden observar tendencia y estacionalidad claras
tsoutliers(datos_pib_ts) #Se detectan varios outliers entre los años 2019 y 2021 que corresponden a la pandemia
ggAcf(datos_pib_ts) #Autocorrelacion
ggPacf(datos_pib_ts) #Autocorrelacion parcial
ggseasonplot(datos_pib_ts,year.labels=TRUE)
ggsubseriesplot(datos_pib_ts)

####

#Vamos a realizar un modelo del pib sin los datos del covid
datos_pib_ts_pandemia <- ts(datos_pib_italia[,3], start = c(1996,1), end = c(2019,4), frequency = 4)
datos_pib_ts_post_pandemia<-ts(datos_pib_italia[,3], start = c(2022,1), end = c(2022,2),frequency = 4)

# Graficar los datos y grafico de autocorrelaciones  ----
ts.plot(datos_pib_ts_pandemia) #Se pueden observar tendencia y estacionalidad claras
tsoutliers(datos_pib_ts_pandemia) #Se detectan varios outliers entre los años 2019 y 2021 que corresponden a la pandemia
ggAcf(datos_pib_ts_pandemia) #Autocorrelacion
ggPacf(datos_pib_ts_pandemia) #Autocorrelacion parcial
ggseasonplot(datos_pib_ts_pandemia,year.labels=TRUE)
ggsubseriesplot(datos_pib_ts_pandemia)

train_pib <- window(datos_pib_ts_pandemia, start = c(1996,1), end = c(2017,4))
test_pib <- window(datos_pib_ts_pandemia, start = c(2018,1), end = c(2019,4))

# Identificar las transformaciones necesarias para conseguir una serie estacionaria en train ----
#PIB
#Estabilizamos varianza con box cox
train_pib_var <- BoxCox(train_pib, BoxCox.lambda(train_pib))

#Esta serie temporal al tener tendencia y estacionalidad hay que quitarselas
#Utilizamos el comando decompose para ver como nos quedaria la serie sin tendencia ni estacionlidad
pib_decompose <- decompose(train_pib_var)
plot(pib_decompose)

modelo_pib<-auto.arima(train_pib_var)
checkresiduals(modelo_pib)
modelo_pib$aic

predicciones<- forecast(modelo_pib,h=8)
predicciones_pib_tr <- InvBoxCox(predicciones$mean, lambda = BoxCox.lambda(train_pib))

accuracy(predicciones_pib_tr,test_pib)

#Con las predicciones anteriores, vamos a sustituir los años 2020 y 2021 del df original, ya que son
#los años afectados por el COVID 19
datos_pib_italia_sin_pandemia<- datos_pib_italia[-c(97:106),]
datos_pib_italia_post_pandemia<-datos_pib_italia[105:106,]
str(datos_pib_italia_sin_pandemia)

#Creamos un df con las predicciones para luego poder juntarlas con el resto de datos
datos_predichos_pandemia<-as.data.frame(predicciones_pib_tr)
colnames(datos_predichos_pandemia)<-c("GDP.billion.currency.units")
datos_predichos_pandemia$Year<-c(2020,2020,2020,2020,2021,2021,2021,2021)
datos_predichos_pandemia$Month<-c(3,6,9,12,3,6,9,12)
datos_predichos_pandemia<-datos_predichos_pandemia[,c(2,3,1)]
str(datos_predichos_pandemia)
datos_pib_italia_2<-rbind(datos_pib_italia_sin_pandemia,datos_predichos_pandemia,datos_pib_italia_post_pandemia)
write.csv(datos_pib_italia_2,'Python/Datos_para_graficar/datos_pib_prediccion_covid.csv', row.names = FALSE)

#Como no es una serie temporal, la convertimos en serie temporal
is.ts(datos_pib_italia_2)
datos_pib_ts_2<-ts(datos_pib_italia_2[,3],start=c(1996,1),end=c(2022,2),frequency = 4)

# Graficar los datos y grafico de autocorrelaciones  ----
ts.plot(datos_pib_ts_2) #Se pueden observar tendencia y estacionalidad claras
tsoutliers(datos_pib_ts_2) #Se detectan varios outliers que pueden corresponderse con los de la crisis del 2008
ggAcf(datos_pib_ts_2) #Autocorrelacion
ggPacf(datos_pib_ts_2) #Autocorrelacion parcial
ggseasonplot(datos_pib_ts_2,year.labels=TRUE)
ggsubseriesplot(datos_pib_ts_2)

#Particion de los datos
train_pib_2<-window(datos_pib_ts_2,start=c(1996,1),end=c(2021,4))
test_pib_2<-window(datos_pib_ts_2,start=c(2022,1),end=c(2022,2))

# Identificar las transformaciones necesarias para conseguir una serie estacionaria en train ----
#PIB
#Estabilizamos varianza con box cox
train_pib_var_2 <- BoxCox(train_pib_2, BoxCox.lambda(train_pib_2))

#Esta serie temporal al tener tendencia y estacionalidad hay que quitarselas
#Utilizamos el comando decompose para ver como nos quedaria la serie sin tendencia ni estacionlidad
pib_decompose_2 <- decompose(train_pib_var_2)
plot(pib_decompose_2)

# Entrenar los modelos y comprobar residuos ----
#MODELO PIB CON AUTO.ARIMA
modelo_pib_2 <- auto.arima(train_pib_var_2)
checkresiduals(modelo_pib_2) 
modelo_pib_2$aic

predicciones<- forecast(modelo_pib_2,h=2)
predicciones_pib_tr <- InvBoxCox(predicciones$mean, lambda = BoxCox.lambda(train_pib_2))

accuracy(predicciones_pib_tr,test_pib_2)

#Vemos que los residuos son ruido blanco
modelo_pib_3 <- arima(train_pib_var_2, order = c(0,1,1), seasonal = c(3,1,3)) 
checkresiduals(modelo_pib_3)
modelo_pib_3$aic

predicciones<- forecast(modelo_pib_3,h=2)
predicciones_pib_tr <- InvBoxCox(predicciones$mean, lambda = BoxCox.lambda(train_pib_2))
predicciones_pib_tr

accuracy(predicciones_pib_tr,test_pib_2)

# Seleccionar mejor algoritmo y realizar las predicciones definitivas ----
predicciones_pib <- forecast(modelo_pib_3, h=4)
predicciones_pib2 <- InvBoxCox(predicciones_pib$mean, lambda = BoxCox.lambda(train_pib_2))
predicciones_pib2 <- predicciones_pib2[4]
predicciones_pib2

autoplot(predicciones_pib)

# La prediccion para el PIB es de 495.179 M€ 
#Segun ISTAT el PIB de italia para el ultimo trimestre fue de 498.856 M€	

################################################################################
#MODELIZACION DEL IPC ----------------------------------------------------------
# Convertir en serie temporal  ----
is.ts(datos_ipc_italia)
datos_ipc_ts <- ts(datos_ipc_italia[,3], start = c(1996,1), end = c(2022,8), frequency = 12)

# Graficar los datos y grafico de autocorrelaciones  ----
ts.plot(datos_ipc_ts) #Se puede observar tendencia clara y estacionalidad desde el 2000 hasta el 2020
tsoutliers(datos_ipc_ts) #Se detectan varios outliers entre los años 2020 y 2021 que corresponden a la pandemia
ggAcf(datos_ipc_ts) #Autocorrelacion
ggPacf(datos_ipc_ts) #Autocorrelacion parcial
ggseasonplot(datos_ipc_ts,year.labels=TRUE)
ggsubseriesplot(datos_ipc_ts)

# Particionar los datos: se usara validacion cruzada 4 veces  ----
train_ipc <- window(datos_ipc_ts, start = c(1996,1), end = c(2021,4))
train_ipc2 <- window(datos_ipc_ts, start = c(1996,1), end = c(2021,8))
train_ipc3 <- window(datos_ipc_ts, start = c(1996,1), end = c(2021,12))
train_ipc4 <- window(datos_ipc_ts, start = c(1996,1), end = c(2022,4))
test_ipc <- window(datos_ipc_ts, start = c(2021,5), end = c(2021,8))
test_ipc2 <- window(datos_ipc_ts, start = c(2021,9), end = c(2021,12))
test_ipc3 <- window(datos_ipc_ts, start = c(2022,1), end = c(2022,4))
test_ipc4 <- window(datos_ipc_ts, start = c(2022,5), end = c(2022,8))

# Identificar las transformaciones necesarias para conseguir una serie estacionaria en train ----
#Estabilizamos varianza con box cox
train_ipc_var <- BoxCox(train_ipc, BoxCox.lambda(train_ipc))
train_ipc_var2 <- BoxCox(train_ipc2, BoxCox.lambda(train_ipc2))
train_ipc_var3 <- BoxCox(train_ipc3, BoxCox.lambda(train_ipc3))
train_ipc_var4 <- BoxCox(train_ipc4, BoxCox.lambda(train_ipc4))

#Esta serie temporal al tener tendencia y estacionalidad hay que quitarselas
#Utilizamos el comando decompose para ver como nos quedaria la serie sin tendencia ni estacionlidad
ipc_decompose <- decompose(train_ipc_var)
plot(ipc_decompose)
ipc_decompose2 <- decompose(train_ipc_var2)
plot(ipc_decompose2)
ipc_decompose3 <- decompose(train_ipc_var3)
plot(ipc_decompose3)
ipc_decompose4 <- decompose(train_ipc_var4)
plot(ipc_decompose4)

#Para quitar la tendencia hacemos la segunda diferencia
train_ipc_sin_tendencia <- diff(train_ipc_var, differences=1)
ggAcf(train_ipc_sin_tendencia)
train_ipc_sin_tendencia2 <- diff(train_ipc_var2, differences=1)
ggAcf(train_ipc_sin_tendencia2)
train_ipc_sin_tendencia3 <- diff(train_ipc_var3, differences=1)
ggAcf(train_ipc_sin_tendencia3)
train_ipc_sin_tendencia4 <- diff(train_ipc_var4, differences=1)
ggAcf(train_ipc_sin_tendencia4)

#Para quitar la estacionalidad de frecuencia semestral hacemos la sexta diferencia
train_ipc_transformado <- diff(train_ipc_sin_tendencia, lag=6)
ggAcf(train_ipc_transformado)
train_ipc_transformado2 <- diff(train_ipc_sin_tendencia2, lag=6)
ggAcf(train_ipc_transformado2)
train_ipc_transformado3 <- diff(train_ipc_sin_tendencia3, lag=6)
ggAcf(train_ipc_transformado3)
train_ipc_transformado4 <- diff(train_ipc_sin_tendencia4, lag=6)
ggAcf(train_ipc_transformado4)

#Ploteamos la serie transformada
ts.plot(train_ipc_transformado)
ts.plot(train_ipc_transformado2)
ts.plot(train_ipc_transformado3)
ts.plot(train_ipc_transformado4)

#Comprobamos si la serie es estacionaria
adftest<-adf.test(train_ipc_transformado)
if (adftest$p.value< 0.05) {print("serie estacionaria")
}else {
  print("serie NO estacionaria")
}
adftest<-adf.test(train_ipc_transformado2)
if (adftest$p.value< 0.05) {print("serie estacionaria")
}else {
  print("serie NO estacionaria")
}
adftest<-adf.test(train_ipc_transformado3)
if (adftest$p.value< 0.05) {print("serie estacionaria")
}else {
  print("serie NO estacionaria")
}
adftest<-adf.test(train_ipc_transformado4)
if (adftest$p.value< 0.05) {print("serie estacionaria")
}else {
  print("serie NO estacionaria")
}
#La serie es estacionaria

# Entrenar los modelos y comprobar residuos ----
#MODELO CON AUTO.ARIMA
modelo_ipc <- auto.arima(train_ipc_transformado)
checkresiduals(modelo_ipc)
modelo_ipc2 <- auto.arima(train_ipc_transformado2)
checkresiduals(modelo_ipc2)
modelo_ipc3 <- auto.arima(train_ipc_transformado3)
checkresiduals(modelo_ipc3)
modelo_ipc4 <- auto.arima(train_ipc_transformado4)
checkresiduals(modelo_ipc4)

#MODELO CON ARIMA HECHO POR NOSOTROS 
#Probamos distintos modelos arima y escogemos el que mejor AIC de
fit000_ipc <- Arima(train_ipc_transformado4, order=c(0,0,0))
fit001_ipc <- Arima(train_ipc_transformado4, order=c(0,0,1))
fit100_ipc <- Arima(train_ipc_transformado4, order=c(1,0,0))
fit002_ipc <- Arima(train_ipc_transformado4, order=c(0,0,2))
fit101_ipc <- Arima(train_ipc_transformado4, order=c(1,0,1))
fit200_ipc <- Arima(train_ipc_transformado4, order=c(2,0,0))
fit003_ipc <- Arima(train_ipc_transformado4, order=c(0,0,3))
fit102_ipc <- Arima(train_ipc_transformado4, order=c(1,0,2))
fit201_ipc <- Arima(train_ipc_transformado4, order=c(2,0,1))
fit300_ipc <- Arima(train_ipc_transformado4, order=c(3,0,0))
fit103_ipc <- Arima(train_ipc_transformado4, order=c(1,0,3))
fit202_ipc <- Arima(train_ipc_transformado4, order=c(2,0,2))
fit301_ipc <- Arima(train_ipc_transformado4, order=c(3,0,1))
fit400_ipc <- Arima(train_ipc_transformado4, order=c(4,0,0))
fit004_ipc <- Arima(train_ipc_transformado4, order=c(0,0,4))
fit203_ipc <- Arima(train_ipc_transformado4, order=c(2,0,3))
fit302_ipc <- Arima(train_ipc_transformado4, order=c(3,0,2))
fit401_ipc <- Arima(train_ipc_transformado4, order=c(4,0,1))
fit104_ipc <- Arima(train_ipc_transformado4, order=c(1,0,4))
fit303_ipc <- Arima(train_ipc_transformado4, order=c(3,0,3))
fit402_ipc <- Arima(train_ipc_transformado4, order=c(4,0,2))
fit204_ipc <- Arima(train_ipc_transformado4, order=c(2,0,4))
fit403_ipc <- Arima(train_ipc_transformado4, order=c(4,0,3))
fit304_ipc <- Arima(train_ipc_transformado4, order=c(3,0,4))
fit404_ipc <- Arima(train_ipc_transformado4, order=c(4,0,4))
fit606_ipc <- Arima(train_ipc_transformado4,order=c(6,0,6))

df_aic_ipc<-data.frame(values = c(fit000_ipc$aic,fit001_ipc$aic,fit002_ipc$aic,fit101_ipc$aic,fit200_ipc$aic,
                                  fit003_ipc$aic,fit102_ipc$aic,fit201_ipc$aic,fit300_ipc$aic,fit103_ipc$aic,
                                  fit202_ipc$aic,fit301_ipc$aic,fit400_ipc$aic,fit004_ipc$aic,fit203_ipc$aic,
                                  fit302_ipc$aic,fit401_ipc$aic,fit104_ipc$aic,fit303_ipc$aic,fit402_ipc$aic,
                                  fit204_ipc$aic,fit403_ipc$aic,fit304_ipc$aic,fit404_ipc$aic,fit606_ipc$aic))
df_aic_ipc$fit<-c("fit000_ipc","fit001_ipc","fit002_ipc","fit101_ipc","fit200_ipc",
                  "fit003_ipc","fit102_ipc","fit201_ipc","fit300_ipc","fit103_ipc",
                  "fit202_ipc","fit301_ipc","fit400_ipc","fit004_ipc","fit203_ipc",
                  "fit302_ipc","fit401_ipc","fit104_ipc","fit303_ipc","fit402_ipc",
                  "fit204_ipc","fit403_ipc","fit304_ipc","fit404_ipc","fit606_ipc")

best_ipc<-df_aic_ipc[which.min(df_aic_ipc$values),]
best_ipc

modelo2_ipc <- arima(train_ipc_transformado, order = c(6,0,6))
checkresiduals(arima(train_ipc_transformado, order = c(6,0,6)))
modelo2_ipc$aic

modelo2_ipc2 <- arima(train_ipc_transformado2, order = c(6,0,6))
checkresiduals(arima(train_ipc_transformado2, order = c(6,0,6)))
modelo2_ipc2$aic

modelo2_ipc3 <- arima(train_ipc_transformado3, order = c(6,0,6))
checkresiduals(arima(train_ipc_transformado3, order = c(6,0,6)))
modelo2_ipc3$aic

modelo2_ipc4 <- arima(train_ipc_transformado4, order = c(6,0,6))
checkresiduals(arima(train_ipc_transformado4, order = c(6,0,6)))
modelo2_ipc4$aic

# Revertir las transformaciones y calcular accuracy para cada algoritmo ----
#Revertir y accuracy para modelo auto.arima para IPC
predicciones_ipc_test <- forecast(modelo2_ipc, h=4)
predicciones_ipc_test_tr <- diffinv(predicciones_ipc_test$mean, lag=6, xi=tail(train_ipc_sin_tendencia,n=6))
predicciones_ipc_test_tr2 <- diffinv(predicciones_ipc_test_tr[-c(1:6)], differences=1, xi=tail(train_ipc_var,n=1))
predicciones_ipc_test_tr3 <- InvBoxCox(predicciones_ipc_test_tr2[-c(1)], lambda = BoxCox.lambda(train_ipc))
predicciones_ipc_test_tr3

test_ipc
accuracy(predicciones_ipc_test_tr3,test_ipc)

predicciones2_ipc_test <- forecast(modelo_ipc2, h=4)
predicciones2_ipc_test_tr <- diffinv(predicciones2_ipc_test$mean, lag=6, xi=tail(train_ipc_sin_tendencia2,n=6))
predicciones2_ipc_test_tr2 <- diffinv(predicciones2_ipc_test_tr[-c(1:6)], differences=1, xi=tail(train_ipc_var2,n=1))
predicciones2_ipc_test_tr3 <- InvBoxCox(predicciones2_ipc_test_tr2[-c(1)], lambda = BoxCox.lambda(train_ipc2))
predicciones2_ipc_test_tr3

test_ipc2
accuracy(predicciones2_ipc_test_tr3,test_ipc2)

predicciones3_ipc_test <- forecast(modelo_ipc3, h=4)
predicciones3_ipc_test_tr <- diffinv(predicciones3_ipc_test$mean, lag=6, xi=tail(train_ipc_sin_tendencia3,n=6))
predicciones3_ipc_test_tr2 <- diffinv(predicciones3_ipc_test_tr[-c(1:6)], differences=1, xi=tail(train_ipc_var3,n=1))
predicciones3_ipc_test_tr3 <- InvBoxCox(predicciones3_ipc_test_tr2[-c(1)], lambda = BoxCox.lambda(train_ipc3))
predicciones3_ipc_test_tr3

test_ipc3
accuracy(predicciones3_ipc_test_tr3,test_ipc3)

predicciones4_ipc_test <- forecast(modelo_ipc4, h=4)
predicciones4_ipc_test_tr <- diffinv(predicciones4_ipc_test$mean, lag=6, xi=tail(train_ipc_sin_tendencia4,n=6))
predicciones4_ipc_test_tr2 <- diffinv(predicciones4_ipc_test_tr[-c(1:6)], differences=1, xi=tail(train_ipc_var4,n=1))
predicciones4_ipc_test_tr3 <- InvBoxCox(predicciones4_ipc_test_tr2[-c(1)], lambda = BoxCox.lambda(train_ipc4))
predicciones4_ipc_test_tr3

test_ipc4
accuracy(predicciones4_ipc_test_tr3,test_ipc4)

#Revertir y accuracy para modelo arima(6,0,6) para IPC
predicciones_ipc_testt <- forecast(modelo2_ipc, h=4)
predicciones_ipc_testt_tr <- diffinv(predicciones_ipc_testt$mean, lag=6, xi=tail(train_ipc_sin_tendencia,n=6))
predicciones_ipc_testt_tr2 <- diffinv(predicciones_ipc_testt_tr[-c(1:6)], differences=1, xi=tail(train_ipc_var,n=1))
predicciones_ipc_testt_tr3 <- InvBoxCox(predicciones_ipc_testt_tr2[-c(1)], lambda = BoxCox.lambda(train_ipc))
predicciones_ipc_testt_tr3

test_ipc
accuracy(predicciones_ipc_testt_tr3,test_ipc)

predicciones2_ipc_testt <- forecast(modelo2_ipc2, h=4)
predicciones2_ipc_testt_tr <- diffinv(predicciones2_ipc_testt$mean, lag=6, xi=tail(train_ipc_sin_tendencia2,n=6))
predicciones2_ipc_testt_tr2 <- diffinv(predicciones2_ipc_testt_tr[-c(1:6)], differences=1, xi=tail(train_ipc_var2,n=1))
predicciones2_ipc_testt_tr3 <- InvBoxCox(predicciones2_ipc_testt_tr2[-c(1)], lambda = BoxCox.lambda(train_ipc2))
predicciones2_ipc_testt_tr3

test_ipc2
accuracy(predicciones2_ipc_testt_tr3,test_ipc2)

predicciones3_ipc_testt <- forecast(modelo2_ipc3, h=4)
predicciones3_ipc_testt_tr <- diffinv(predicciones3_ipc_testt$mean, lag=6, xi=tail(train_ipc_sin_tendencia3,n=6))
predicciones3_ipc_testt_tr2 <- diffinv(predicciones3_ipc_testt_tr[-c(1:6)], differences=1, xi=tail(train_ipc_var3,n=1))
predicciones3_ipc_testt_tr3 <- InvBoxCox(predicciones3_ipc_testt_tr2[-c(1)], lambda = BoxCox.lambda(train_ipc3))
predicciones3_ipc_testt_tr3

test_ipc3
accuracy(predicciones3_ipc_testt_tr3,test_ipc3)

predicciones4_ipc_testt <- forecast(modelo2_ipc4, h=4)
predicciones4_ipc_testt_tr <- diffinv(predicciones4_ipc_testt$mean, lag=6, xi=tail(train_ipc_sin_tendencia4,n=6))
predicciones4_ipc_testt_tr2 <- diffinv(predicciones4_ipc_testt_tr[-c(1:6)], differences=1, xi=tail(train_ipc_var4,n=1))
predicciones4_ipc_testt_tr3 <- InvBoxCox(predicciones4_ipc_testt_tr2[-c(1)], lambda = BoxCox.lambda(train_ipc4))
predicciones4_ipc_testt_tr3

test_ipc4
accuracy(predicciones4_ipc_testt_tr3,test_ipc4)

# Seleccionar mejor algoritmo y realizar las predicciones definitivas ----
predicciones_ipc <- forecast(modelo2_ipc4, h=8)
predicciones_ipc2 <- diffinv(predicciones_ipc$mean, lag=6, xi=tail(train_ipc_sin_tendencia4,n=6))
predicciones_ipc3 <- diffinv(predicciones_ipc2[-c(1:6)], differences=1, xi=tail(train_ipc_var4,n=1))
predicciones_ipc4 <- InvBoxCox(predicciones_ipc3[-1], lambda = BoxCox.lambda(train_ipc4))
predicciones_ipc4 <- predicciones_ipc4[6:8]
predicciones_ipc4
autoplot(predicciones_ipc)

#Las predicciones para el IPC son 114.8475  M€ para oct, 115.5304 M€ para nov y 116.3154 M€ para dic.
##Segun ISTAT el IPC de italia fueron 118.1 M€ para oct, 118,7	M€ para nov y 119 M€ para dic.
