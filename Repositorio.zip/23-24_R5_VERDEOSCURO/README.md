# RETO 05 EQUIPO VERDE OSCURO
Repositorio de Github del equipo verde oscuro para el reto 5

Autores: Ane Aizpuru, June Dorronsoro, Lian Etxebarria, Julen Fernandez, June Marquinez y Guillermo Rubio. 

En este documento se detallará la estructura del proyecto. 
El proyecto consta de 4 tipos de carpetas principales: datos, scripts, influxdb y gráficos.

En la carpeta de datos hay dos subcarpetas, originales y transformados. En la primera, están todos los datos proporcionados por el cliente (Laboral Kutxa). En la segunda, se encuentran los datos que se han ido generando a lo largo del reto. Todos estos datos no se subirán al repositorio en remoto, tal y como se puede ver en el fichero .gitignore. Esto es, todos los archivos dentro de la carpeta de datos serán ignorados al hacer el comando git push.

En las carpetas de scripts se encuentran todos los scripts que se han creado para poder realizar el reto dividos segun dos tipos: preprocesamiento y modelos. En cada uno de ellos habrá al principio, un source que ejecutará los scripts necesarios para que ese funcione, y al final, estará el comando write.csv para que los datos generados se guarden en la carpeta de datos transformados. Todo estos scripts se pueden ejecutar de manera independiente.

Por  último, en la carpeta de gráficos están las imágenes de los gráficos que se han hecho para visualizar los resultados, que luego se insertarán en el informe.
