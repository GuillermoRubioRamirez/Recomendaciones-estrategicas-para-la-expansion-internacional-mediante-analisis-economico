# Limpiar entorno -----
rm(list=ls())

# LIBRERÍAS -----
{
  source('Scripts/librerias.R', encoding = "UTF-8")
}

# INGESTA Y LIMIPIEZA DE DATOS -----
{
  source('Scripts/Scripts_preprocesamiento/Limpieza.R', encoding = "UTF-8")
}

# Limpiar entorno -----
rm(list=ls())

# EDA -----
{
  source('Scripts/Scripts_preprocesamiento/Graficos_EDA.R', encoding = "UTF-8")
}

# Limpiar entorno -----
rm(list=ls())

# MODELOS ----
{
  source('Scripts/Scripts_modelos/Preparacion_modelo.R', encoding = "UTF-8")
}

# Limpiar entorno -----
rm(list=ls())

#Preparacion Graficos Python -----
{
  source('Scripts/preparacion_graficos_python.R',encoding = 'UTF-8')
}

#Limpiar entorno -----
rm(list=ls())

#Creacion bucket
{
  source('InfluxDB/creacion_bucket.R', encoding = 'UTF-8')
}

#Limpiar entorno -----
rm(list=ls())

#Consultas InfluxDB -----
{
  source('InfluxDB/consultas.R', encoding = 'UTF-8')
}

#Limpiar entorno -----
rm(list=ls())
