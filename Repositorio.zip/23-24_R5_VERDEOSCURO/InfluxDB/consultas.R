# CONSULTAS INFLUXDB


client <- InfluxDBClient$new(url = "http://localhost:8086",
                             token = "fPk8o2Qa0zKQ1eR-EZGgHMXkzliatiFIV-FN1o25ZImcnJa43HRJpQs9_vY9xTEADYMlYoxjw5K2om4RozOz1A==",
                             org = "mondragon")
client$health()

# Consulta 1: Tasa de paro en Italia durante el año 2000 -----

consulta1 <- 'from(bucket: "bucket_R05_verdeoscuro_exg")
  |> range(start: 2000-01-01T00:00:01Z, stop: 2001-01-01T00:00:01Z)
  |> filter(fn: (r) => r["Country"] == "Italy")
  |> filter(fn: (r) => r["Code"] == "ITA")
  |> filter(fn: (r) => r["ContinentCode"] == "EU")
  |> filter(fn: (r) => r["_field"] == "Unemployment.rate.percent")'

consulta1 <- gsub("[\r\n<]", "", consulta1) # ignoramos los saltos de línea

data1 <- client$query(consulta1)

# Consulta 2: IPC medio de Italia por año desde 1996 a 2001 -----

consulta2 <- 'import "contrib/bonitoo-io/tickscript"
from(bucket: "bucket_R05_verdeoscuro_ipc")
  |> range(start: 1996-01-01T00:00:01Z, stop: 2001-01-01T00:00:01Z)
  |> filter(fn: (r) => r["Country"] == "Italy")
  |> filter(fn: (r) => r["Code"] == "ITA")
  |> filter(fn: (r) => r["ContinentCode"] == "EU")
  |> filter(fn: (r) => r["_field"] == "Consumer.Price.Index..CPI.")
  |> aggregateWindow(every: 1y, fn: mean)
  |> yield(name: "mean")'

consulta2 <- gsub("[\r\n<]", "", consulta2) # ignoramos los saltos de línea

data2 <- client$query(consulta2)

# Consulta 3: Países ordenados según su PIB medio en el año 2000 -----

consulta3 <- 'from(bucket: "bucket_R05_verdeoscuro_pib")
  |> range(start: 2000-01-01T00:00:01Z, stop: 2001-01-01T00:00:01Z)
  |> filter(fn: (r) => r["_measurement"] == "France" or r["_measurement"] == "Germany" or r["_measurement"] == "Italy" or r["_measurement"] == "Norway" or r["_measurement"] == "United Kingdom")
  |> filter(fn: (r) => r["Code"] == "DEU" or r["Code"] == "FRA" or r["Code"] == "GBR" or r["Code"] == "ITA" or r["Code"] == "NOR")
  |> filter(fn: (r) => r["ContinentCode"] == "EU")
  |> filter(fn: (r) => r["Country"] == "France" or r["Country"] == "Italy" or r["Country"] == "United Kingdom" or r["Country"] == "Norway" or r["Country"] == "Germany")
  |> filter(fn: (r) => r["_field"] == "GDP.billion.currency.units")
  |> aggregateWindow(every: 1y, fn: mean, createEmpty: false)
  |> group(columns: ["ContinentCode"])
  |> yield(name: "mean")
  |> sort(columns: ["_value"], desc: false)
  |> keep(columns: ["mean"])'

consulta3 <- gsub("[\r\n<]", "", consulta3) # ignoramos los saltos de línea

data3 <- client$query(consulta3)
