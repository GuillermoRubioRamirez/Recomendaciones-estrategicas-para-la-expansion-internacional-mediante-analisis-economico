# CREACIÓN DEL BUCKET PARA INFLUXDB

# 1) Making a connection (API) -----
client <- InfluxDBClient$new(url = "http://localhost:8086",
                             token = "fPk8o2Qa0zKQ1eR-EZGgHMXkzliatiFIV-FN1o25ZImcnJa43HRJpQs9_vY9xTEADYMlYoxjw5K2om4RozOz1A==",
                             org = "mondragon")
client$health()

# 2.1) Buckets para PIB e IPC ----------------------------------------------------

# 1) read.csv() -----
data1 <- read.csv("Datos/Originales/pib_ipc_paises_punto2.csv", sep = ',')
# separamos PIB e IPC e omitimos NAs
data_pib <- data1[, -7]
data_pib <- na.omit(data_pib)
data_ipc <- data1[, -6]
data_ipc <- na.omit(data_ipc)

# 2) Previsualización de los datos
summary(data_pib)
str(data_pib)
dim(data_pib)
head(data_pib)
colnames(data_pib)
summary(data_ipc)
str(data_ipc)
dim(data_pib)
head(data_pib)

# 3) Detectar posibles duplicidades
table(duplicated(data_pib))           #no hay duplicados
table(duplicated(data_ipc))           #no hay duplicados

# 4) Create a bucket -----
INFLUX_TOKEN = "fPk8o2Qa0zKQ1eR-EZGgHMXkzliatiFIV-FN1o25ZImcnJa43HRJpQs9_vY9xTEADYMlYoxjw5K2om4RozOz1A=="
Influx_Authorization_Header <- paste ("Token", INFLUX_TOKEN)
INFLUX_URL = "http://localhost:8086/api/v2/buckets"
INFLUX_ORG_ID_PIB = '{
"name": "bucket_R05_verdeoscuro_pib",
"orgID": "a1b63c12f67db548"
}'
INFLUX_ORG_ID_IPC = '{
"name": "bucket_R05_verdeoscuro_ipc",
"orgID": "a1b63c12f67db548"
}'
response_pib <- POST(INFLUX_URL,
                 body = INFLUX_ORG_ID_PIB,
                 accept("application/csv"),
                 content_type("application/json"),
                 add_headers(Authorization = Influx_Authorization_Header)
)
response_ipc <- POST(INFLUX_URL,
                     body = INFLUX_ORG_ID_IPC,
                     accept("application/csv"),
                     content_type("application/json"),
                     add_headers(Authorization = Influx_Authorization_Header)
)

# 5) Data Formatting -----
data_pib$Day <- 1
data_pib$dates <- as.Date(with(data_pib, paste(Year, Month, Day, sep = "-")), "%Y-%m-%d")
data_pib$times <- "00:00:01.0"
data_pib$Date <- paste(data_pib$dates, data_pib$times)
data_pib$Date <- strptime(data_pib$Date, "%Y-%m-%d %H:%M:%S", tz = "GMT")
data_pib$Date <- as.POSIXct(data_pib$Date)
str(data_pib)
data_ipc$Day <- 1
data_ipc$dates <- as.Date(with(data_ipc, paste(Year, Month, Day, sep = "-")), "%Y-%m-%d")
data_ipc$times <- "00:00:01.0"
data_ipc$Date <- paste(data_ipc$dates, data_ipc$times)
data_ipc$Date <- strptime(data_ipc$Date, "%Y-%m-%d %H:%M:%S", tz = "GMT")
data_ipc$Date <- as.POSIXct(data_ipc$Date)
str(data_ipc)

# 6) Write data -----
response_pib <- client$write(data_pib, bucket = "bucket_R05_verdeoscuro_pib", precision = "s",   #'s': segundos
                             measurementCol = "Country",
                             tagCols = c("Code", "Country", "ContinentCode"),
                             fieldCols = c("GDP.billion.currency.units"),
                             timeCol = "Date")
response_ipc <- client$write(data_ipc, bucket = "bucket_R05_verdeoscuro_ipc", precision = "s",   #'s': segundos
                             measurementCol = "Country",
                             tagCols = c("Code", "Country", "ContinentCode"),
                             fieldCols = c("Consumer.Price.Index..CPI."),
                             timeCol = "Date")


# 2.2) Bucket para datos exógenas ------------------------------------------------

# 1) read.csv() -----
data_exg <- read.csv("Datos/Originales/exogenas-paises-punto2.csv", sep = ',')
data_exg <- na.omit(data_exg) #con na.omit() se pierden muchas instancias, pero muy pocas son de Italia
summary(data_exg)
str(data_exg)

# 2) Previsualización de los datos
summary(data_exg)
str(data_exg)
dim(data_exg)
head(data_exg)
colnames(data_exg)

# 3) Detectar posibles duplicidades
table(duplicated(data_exg))           #no hay duplicados

# 4) Create a bucket -----
INFLUX_TOKEN = "fPk8o2Qa0zKQ1eR-EZGgHMXkzliatiFIV-FN1o25ZImcnJa43HRJpQs9_vY9xTEADYMlYoxjw5K2om4RozOz1A=="
Influx_Authorization_Header <- paste ("Token", INFLUX_TOKEN)
INFLUX_URL = "http://localhost:8086/api/v2/buckets"
INFLUX_ORG_ID_EXG = '{
"name": "bucket_R05_verdeoscuro_exg",
"orgID": "a1b63c12f67db548"
}'
response_exg <- POST(INFLUX_URL,
                     body = INFLUX_ORG_ID_EXG,
                     accept("application/csv"),
                     content_type("application/json"),
                     add_headers(Authorization = Influx_Authorization_Header)
)

# 5) Data Formatting -----
data_exg$Day <- 1
data_exg$dates <- as.Date(with(data_exg, paste(Year, Month, Day, sep = "-")), "%Y-%m-%d")
data_exg$times <- "00:00:01.0"
data_exg$Date <- paste(data_exg$dates, data_exg$times)
data_exg$Date <- strptime(data_exg$Date, "%Y-%m-%d %H:%M:%S", tz = "GMT")
data_exg$Date <- as.POSIXct(data_exg$Date)
str(data_exg)

# 6) Write data -----
response_exg <- client$write(data_exg, bucket = "bucket_R05_verdeoscuro_exg", precision = "s",   #'s': segundos
                             measurementCol = "Country",
                             tagCols = c("Code", "Country", "ContinentCode"),
                             fieldCols = c("Money.supply.billion.currency.units", "Unemployment.rate.percent", "Stock.market.index"),
                             timeCol = "Date")




